return {
  ["workshop-1085586145"]={
    ["configuration_options"]={
      ["additional_building"]="open",
      ["additional_chesspieces"]="open",
      ["additional_dress"]="open",
      ["additional_experiment"]="open",
      ["additional_food"]="open",
      ["additional_orbit"]="open",
      ["additional_survival"]="open",
      ["additional_weapon"]="open",
      ["dev_mode"]="disabled",
      ["dress_uses"]="normal",
      ["food_effect"]="normal",
      ["language"]="english",
      ["survival_effect"]="normal",
      ["tooltip_enhance"]="open",
      ["weapon_damage"]="normal",
      ["weapon_uses"]="normal" 
    },
    ["enabled"]=true 
  },
  ["workshop-1418746242"]={
    ["configuration_options"]={
      ["clearfont"]=true,
      ["eventplus"]=true,
      ["extratrans"]=true,
      ["workshop-345692228"]=0,
      ["workshop-351325790"]=0,
      ["workshop-376333686"]=0,
      ["workshop-378160973"]=0 
    },
    ["enabled"]=true 
  },
  ["workshop-1508510758"]={ ["configuration_options"]={  }, ["enabled"]=true },
  ["workshop-347079953"]={
    ["configuration_options"]={ ["DFV_Language"]="EN", ["DFV_MinimalMode"]="default" },
    ["enabled"]=true 
  },
  ["workshop-378160973"]={
    ["configuration_options"]={
      ["ENABLEPINGS"]=true,
      ["FIREOPTIONS"]=2,
      ["OVERRIDEMODE"]=false,
      ["SHAREMINIMAPPROGRESS"]=true,
      ["SHOWFIREICONS"]=true,
      ["SHOWPLAYERICONS"]=true,
      ["SHOWPLAYERSOPTIONS"]=2 
    },
    ["enabled"]=true 
  },
  ["workshop-398858801"]={
    ["configuration_options"]={
      ["afk_enabled"]=true,
      ["afk_host_immunity"]=true,
      ["afk_hunger_decrease"]=true,
      ["afk_max_action"]=1,
      ["afk_max_time"]=0,
      ["afk_stop_beaver"]=true,
      ["afk_stop_death"]=true,
      ["afk_stop_sanity"]=true,
      ["afk_stop_wet"]=true,
      ["afk_temp"]=true,
      ["afk_time"]=120 
    },
    ["enabled"]=true 
  },
  ["workshop-447092740"]={ ["configuration_options"]={  }, ["enabled"]=true },
  ["workshop-666155465"]={
    ["configuration_options"]={
      ["food_estimation"]=-1,
      ["food_order"]=0,
      ["food_style"]=0,
      ["lang"]="auto",
      ["show_food_units"]=-1 
    },
    ["enabled"]=true 
  },
  ["workshop-721491336"]={
    ["configuration_options"]={
      ["Death Lv Drain (Trust)"]="Off",
      ["General Winter"]="On",
      ["Phoenix's Resilience"]="On",
      ["Survivor's Guilt"]="On",
      ["Trustworthy"]="On" 
    },
    ["enabled"]=true 
  },
  ["workshop-723721217"]={
    ["configuration_options"]={ ["Reluctant Fighter"]="On", ["Serious Side"]="On", ["Truly an Angel"]="On" },
    ["enabled"]=true 
  },
  ["workshop-727325644"]={
    ["configuration_options"]={ ["Lightning Speed"]="On", ["Rely on Me!"]="On", ["Weigh Anchor"]="On" },
    ["enabled"]=true 
  },
  ["workshop-729309574"]={
    ["configuration_options"]={ ["Draw Fire"]="On", ["Nameship Leadership"]="On", ["Properly Dressed"]="On" },
    ["enabled"]=true 
  },
  ["workshop-732983003"]={ ["configuration_options"]={ ["lang"]=1 }, ["enabled"]=true },
  ["workshop-831523966"]={ ["configuration_options"]={  }, ["enabled"]=true },
  ["workshop-897634060"]={
    ["configuration_options"]={ ["Lucky Survivor"]="On", ["Priority Redirection"]="On", ["Soothing Rain"]="On" },
    ["enabled"]=true 
  } 
}